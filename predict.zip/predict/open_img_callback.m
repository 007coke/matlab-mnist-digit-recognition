function open_img_callback(~,~)
global g_model g_ax1 g_ax2 g_ax3 g_ax4 g_ax5 g_ax6
[fname,fpath] = uigetfile(...
    {'*.jpg;*.jpeg;*.png;*.bmp','ͼƬ�ļ�(*.jpg,*.jpeg,*.png,*.bmp)'},...
    'ѡ����д����ͼƬ');
if isequal(fname,0)
    return;
end
full_path = fullfile(fpath,fname);
recognize_digit(full_path);
end
